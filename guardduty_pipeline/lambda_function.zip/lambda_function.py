import json
import boto3
import botocore.exceptions
import os

def lambda_handler(event, context):
    # Assume role in management account
    management_role_arn = f"arn:aws:iam::{os.environ['MANAGEMENT_ACCOUNT_ID']}:role/EC2TerminationRole"
    sts_client = boto3.client('sts')
    try:
        assumed_role = sts_client.assume_role(
            RoleArn=management_role_arn,
            RoleSessionName="GuardDutyRemediation"
        )
        credentials = assumed_role['Credentials']
        print(f"Successfully assumed role: {management_role_arn}")
    except botocore.exceptions.ClientError as e:
        print(f"Failed to assume role: {e}")
        return {'statusCode': 500, 'body': f'Error assuming role: {e}'}

    # Use assumed credentials for EC2 client
    ec2 = boto3.client(
        'ec2',
        aws_access_key_id=credentials['AccessKeyId'],
        aws_secret_access_key=credentials['SecretAccessKey'],
        aws_session_token=credentials['SessionToken']
    )

    # Existing SES and S3 clients
    ses = boto3.client('ses')
    s3 = boto3.client('s3')

    # Process the GuardDuty finding
    try:
        finding = event['detail']
        instance_id = finding['resource']['instanceDetails'].get('instanceId')
        if not instance_id or not instance_id.startswith('i-') or len(instance_id) != 19:
            raise ValueError(f"Invalid instance ID: {instance_id}")
        print(f"Processing instance: {instance_id}")
    except (KeyError, ValueError) as e:
        print(f"Error parsing instance ID: {e}")
        return {'statusCode': 400, 'body': f'Error: Invalid or missing instance ID {e}'}

    bucket_name = f"{os.environ['S3_BUCKET_PREFIX']}-{finding['accountId'][-8:]}"
    ses_email_source = os.environ['SES_EMAIL_SOURCE']
    ses_email_recipient = os.environ['SES_EMAIL_RECIPIENT']

    # Attempt termination
    try:
        ec2.terminate_instances(InstanceIds=[instance_id])
        print(f"✅ Successfully terminated instance: {instance_id}")
    except botocore.exceptions.ClientError as e:
        print(f"❌ Error terminating instance {instance_id}: {e}")
        return {'statusCode': 500, 'body': f'Error terminating instance: {e}'}

    # Proceed with S3 and SES only if termination succeeds
    try:
        s3.put_object(
            Bucket=bucket_name,
            Key=f"findings/{finding['id']}.json",
            Body=json.dumps(finding)
        )
        print(f"✅ Stored finding in S3: {bucket_name}/findings/{finding['id']}.json")
    except botocore.exceptions.ClientError as e:
        print(f"⚠️ Error storing finding in S3: {e}")

    try:
        ses.send_email(
            Source=ses_email_source,
            Destination={'ToAddresses': [ses_email_recipient]},
            Message={
                'Subject': {'Data': 'Crypto Mining Detected'},
                'Body': {'Text': {'Data': f'Instance {instance_id} terminated due to crypto mining.'}}
            }
        )
        print(f"✅ Sent SES email to {ses_email_recipient}")
    except botocore.exceptions.ClientError as e:
        print(f"⚠️ Error sending SES email: {e}")

    return {'statusCode': 200, 'body': f'Instance {instance_id} terminated'}