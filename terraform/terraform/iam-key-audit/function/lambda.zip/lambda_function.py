import boto3
import os
from datetime import datetime, timezone

def lambda_handler(event, context):
    iam = boto3.client('iam')
    ses = boto3.client('ses')

    sender = os.environ['SES_SENDER']
    recipient = os.environ['SES_RECIPIENT']
    max_age_days = int(os.environ.get('MAX_AGE_DAYS', '90'))

    old_keys = []

    users = iam.list_users()['Users']
    for user in users:
        username = user['UserName']
        keys = iam.list_access_keys(UserName=username)['AccessKeyMetadata']
        for key in keys:
            create_date = key['CreateDate']
            age = (datetime.now(timezone.utc) - create_date).days
            if age > max_age_days:
                old_keys.append({
                    'UserName': username,
                    'AccessKeyId': key['AccessKeyId'],
                    'AgeInDays': age
                })

    if old_keys:
        body = "The following IAM users have access keys older than {} days:\n\n".format(max_age_days)
        for entry in old_keys:
            body += f"User: {entry['UserName']}, AccessKeyId: {entry['AccessKeyId']}, Age: {entry['AgeInDays']} days\n"

        ses.send_email(
            Source=sender,
            Destination={'ToAddresses': [recipient]},
            Message={
                'Subject': {'Data': '⚠️ AWS IAM Access Key Rotation Alert'},
                'Body': {'Text': {'Data': body}}
            }
        )

    return {
        'statusCode': 200,
        'body': 'IAM access key audit complete. Email sent if old keys were found.'
    }
